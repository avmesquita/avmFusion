﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Impeto.Exchange.Configuration.Models
{
    [Table("TB_CLIENTE")]
    public class ClienteModel
    {
        [Key]
        [Display(Name ="Código")]
        [Column("COD_CLIENTE")]
        public int Codigo { get; set; }

        [Display(Name = "Nome")]
        [Column("TXT_NOME")]
        [Required(ErrorMessage = "Informe o nome do cliente")]
        public string Nome { get; set; }

        [Display(Name = "Conta SMTP")]
        [Column("TXT_SMTP")]
        [Required(ErrorMessage = "Informe o SMTP do cliente")]
        public string Smtp { get; set; }

        [Display(Name = "Senha do SMTP")]
        [Column("TXT_SENHA")]
        [Required(ErrorMessage = "Informe a senha do SMTP do cliente")]                
        public string Senha { get; set; }

        [Display(Name = "Fuso Horário")]
        [Column("TXT_TIMEZONE")]
        [Required(ErrorMessage = "Selecione o Fuso Horário")]
        public string TimeZone { get; set; }

        [Display(Name = "Token de Segurança")]
        [Column("TXT_TOKEN")]
        [Required(ErrorMessage = "Informe o token de segurança docliente")]
        public string Token { get; set; }

        [Display(Name = "Data de Cadastro")]
        [Column("DAT_CADASTRO")]        
        public string DataCadastro { get; set; }

        [Column("COD_PLANO")]
        public int CodigoPlano { get; set; }

        [ForeignKey("CodigoPlano")]
        public PlanoModel Plano { get; set; }

        public ClienteModel()
        {
            Codigo = 0;
            Nome = "";
            Smtp = "";
            Senha = "";
            TimeZone = "";
            Token = "";
            Plano = new PlanoModel();
        }
    }
}