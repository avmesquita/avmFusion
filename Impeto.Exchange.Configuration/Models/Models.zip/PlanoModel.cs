﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Impeto.Exchange.Configuration.Models
{
    [Table("TB_PLANO")]
    public class PlanoModel 
    {
        [Key]
        [Display(Name = "Código")]
        [Column("COD_PLANO")]
        public int Codigo { get; set; }

        [Display(Name = "Título")]
        [Column("TXT_TITULO")]
        [Required(ErrorMessage = "Informe o título do plano")]
        public string Titulo { get; set; }

        [Display(Name = "Qtde de Dispostivos Suportados")]
        [Column("NUM_QUANTIDADE")]
        [Required(ErrorMessage = "Informe a quantidade de dispositivos coberto pelo plano")]
        public int QtdeDispositivos { get; set; }

        [Display(Name = "Data de Início de Vigência")]
        [Column("DAT_INICIO_VIGENCIA")]
        [Required(ErrorMessage = "Informe a data de início de vigência do plano")]
        public DateTime InicioVigencia { get; set; }

        [Display(Name = "Data de Fim de Vigência")]
        [Column("DAT_FIM_VIGENCIA")]
        [Required(ErrorMessage = "Informe a data de fim de vigência do plano")]
        public DateTime FimVigencia { get; set; }

        [Display(Name = "Preço")]
        [Column("VAL_PRECO")]
        [Required(ErrorMessage = "Informe o preço de venda do plano")]
        public Decimal Valor { get; set; }

        public PlanoModel()
        {
            Codigo = 0;
            Titulo = "";
            QtdeDispositivos = 0;
            InicioVigencia = DateTime.MinValue;
            FimVigencia = DateTime.MaxValue;
            Valor = 0;
        }

    }
}