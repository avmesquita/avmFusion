﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Impeto.Framework.Exchange.Models
{
    public enum ConfiguracaoTipo
    {
        ConfiguracaoPorExchange = 0,
        ConfiguracaoPorArquivo = 1
    }

    public enum GetRoomTipo
    {
        ConfiguracaoPorExchange = 0,
        ConfiguracaoPorArquivo = 1
    }
}
